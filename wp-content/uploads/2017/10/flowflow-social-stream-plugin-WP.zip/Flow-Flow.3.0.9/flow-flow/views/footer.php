<div class="section footer">
    <div class="width-wrapper"><div class="ff-table"><div class="ff-cell">
                Flow-Flow Social Stream plugin<br>
                Version: <?php echo $context['version'];?><br>
                Made by <a href="http://looks-awesome.com/">Looks Awesome</a>
            </div>
            <div class="ff-cell">
                <h1>HOT TOPICS</h1>
                <a target="_blank" href="http://docs.social-streams.com/article/42-first-steps-flow-wp">First Steps With Plugin</a><br>
                <a target="_blank" href="http://docs.social-streams.com/article/46-authenticate-with-facebook">Connect Facebook</a><br>
                <a target="_blank" href="http://docs.social-streams.com/article/56-issues-using-big-number-of-feeds">Issues With Streams</a><br>
                <a target="_blank" href="http://docs.social-streams.com/collection/104-faq">Frequently Asked Questions</a>
            </div>
            <div class="ff-cell">
                <h1>USEFUL LINKS</h1>
                <a href="http://looks-awesome.com/help">Help Center</a><br>
                <a href="http://looks-awesome.com/">Looks Awesome Site</a><br>
                <a href="https://twitter.com/looks_awesooome">LA Twitter</a><br>
                <a href="https://www.facebook.com/looksawesooome">LA Facebook</a>
            </div>
        </div>
    </div>
</div>